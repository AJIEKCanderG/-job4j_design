package ru.job4j.io;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Scanner;
import java.util.function.Predicate;

/**
 * 2. Создать класс CSVReader. Задача класса прочитать данные из CSV файла и вывести их.
 * В качестве входных данных задается путь к файлу path, разделитель delimiter, приемник данных out и фильтр
 * по столбцам filter.
 * Ключ -out имеет только два допустимых значения stdout или путь к файлу, куда нужно вывести.
 * Например, если есть файл CSV со столбцами name, age, birthDate, education, children и программа запускается таким образом:
 * java -jar target/csvReader.jar -path=file.txt -delimiter=";"  -out=stdout -filter=name,age
 * то программа должна прочитать файл по пути file.txt и вывести только столбцы name, age в консоль.
 * В качестве разделителя данных выступает ;
 * 3. Для чтения аргументов использовать класс Args и задания "5.1. Именованные аргументы".
 * 4. Программа должна запускаться с консоли в виде jar файла как показано в примере.
 * 5. Для чтения файла использовать класс Scanner.
 * 6. Добавить валидацию аргументов, как в классе Search.
 */


public class CSVReader {
    public static void checkArgs(String[] args) throws IOException {
        if (args.length == 0) {
            throw new IllegalArgumentException("Root folder is null. Usage java -jar dir.jar ROOT_FOLDER.");
        }

        if (args.length < 2 || args[1].isEmpty()) {
            throw new IllegalArgumentException("File extension is null");
        }
        Path start = Paths.get(args[0]);
        search(start, p -> p.toFile().getName().endsWith(args[1])).forEach(System.out::println);
    }

    public static List<Path> search(Path root, Predicate<Path> condition) throws IOException {
        SearchFiles searcher = new SearchFiles(condition);
        Files.walkFileTree(root, searcher);
        return searcher.getPaths();
    }


    public void read() throws FileNotFoundException {
        Scanner scanner = new Scanner(new File("./src/main/resources/file.csv"));
        while (scanner.hasNextLine()) {
            String textFromFile = scanner.nextLine();
            System.out.println(textFromFile);
        }
    }


    public static void main(String[] args) throws IOException {
        ArgsName argNames = ArgsName.of(args);
        Scanner scanner = new Scanner(new File("./src/main/resources/file.csv"));
        while (scanner.hasNextLine()) {
            String textFromFile = scanner.nextLine();
            System.out.println(textFromFile);
        }

    }
}

