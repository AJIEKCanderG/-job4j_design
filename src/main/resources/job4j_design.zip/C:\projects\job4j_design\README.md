[![Build Status](https://www.travis-ci.com/AJIEKCanderG/job4j_design.svg?branch=master)](https://www.travis-ci.com/AJIEKCanderG/job4j_design)
[![codecov](https://codecov.io/gh/AJIEKCanderG/job4j_design/branch/master/graph/badge.svg)](https://codecov.io/gh/AJIEKCanderG/job4j_design)
## job4j_design

### Tемы, пройденные в проекте:
* Maven
* Итераторы
* Обобщения
* Коллекции: List
* Коллекции: Set
* Коллекции: Map
* Коллекции: Tree
* Ввод/вывод
* Сокеты
* Логирование
* Сериализация
* Настройка PostgreSQL
* CREATE, UPDATE, INSERT
* Базовые запросы
* Внешние соединения
